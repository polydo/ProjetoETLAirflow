-- KPI 1: Faturamento Bruto Total
-- Explicação: Valor total das vendas antes de qualquer desconto.
SELECT 
    SUM(qtd_vendida * valor_unitario) AS faturamento_bruto
FROM public.f_vendas;

-- KPI 2: Faturamento Líquido Total
-- Explicação: Receita real que entrou no caixa (Faturamento Bruto - Descontos).
SELECT 
    SUM(valor_total) AS faturamento_liquido
FROM public.f_vendas;

-- KPI 3: Lucro Bruto Total (Diferencial do seu trabalho)
-- Explicação: Quanto sobrou após pagar o custo do produto (Receita Líquida - Custo).
SELECT 
    SUM(valor_total - (custo_unitario * qtd_vendida)) AS lucro_bruto
FROM public.f_vendas;

-- KPI 4: Margem de Lucro Global (%)
-- Explicação: Eficiência do negócio. Para cada R$ 100 vendidos, quanto é lucro?
SELECT 
    ROUND(
        (SUM(valor_total - (custo_unitario * qtd_vendida)) / NULLIF(SUM(valor_total),0)) * 100, 
    2) AS margem_lucro_percentual
FROM public.f_vendas;

-- KPI 5: Ticket Médio por Pedido
-- Explicação: Valor médio gasto por cada compra realizada.
SELECT 
    ROUND(AVG(total_pedido), 2) AS ticket_medio
FROM (
    SELECT numero_pedido, SUM(valor_total) as total_pedido
    FROM public.f_vendas
    GROUP BY numero_pedido
) subquery;

-- KPI 6: Faturamento por Canal de Venda (Online vs. Revenda)
-- Explicação: Compara a performance das vendas diretas online contra lojas revendedoras.
SELECT 
    CASE 
        WHEN eh_venda_online = true THEN 'Venda Online'
        ELSE 'Revenda / Loja Física'
    END AS canal_venda,
    TO_CHAR(SUM(valor_total), 'FM999G999G999D00') AS total_faturado,
    COUNT(DISTINCT numero_pedido) AS qtd_pedidos
FROM public.f_vendas
GROUP BY eh_venda_online;

-- KPI 7: Taxa Média de Desconto (%)
-- Explicação: Agressividade comercial. Qual a média de desconto concedida nas vendas que tiveram promoção?
SELECT 
    ROUND(AVG(valor_desconto / NULLIF(qtd_vendida * valor_unitario, 0)) * 100, 2) AS media_desconto_concedido
FROM public.f_vendas
WHERE valor_desconto > 0;

-- KPI 8: Top 5 Produtos Mais Rentáveis (Lucro)
-- Explicação: Produtos que trazem mais dinheiro "limpo" para a empresa (não apenas volume).
SELECT 
    p.nome_produto,
    p.nome_categoria,
    SUM(f.valor_total) AS receita_total,
    SUM(f.valor_total - (f.custo_unitario * f.qtd_vendida)) AS lucro_gerado
FROM public.f_vendas f
JOIN public.d_produto p ON f.sk_produto = p.sk_produto
GROUP BY p.nome_produto, p.nome_categoria
ORDER BY lucro_gerado DESC
LIMIT 5;

-- KPI 9: Faturamento por Região Continental (Grupo de Território)
-- Explicação: Visão macrogeográfica das vendas.
SELECT 
    l.grupo_territorio, -- Ex: North America, Europe
    SUM(f.valor_total) AS total_vendas
FROM public.f_vendas f
JOIN public.d_localidade l ON f.sk_localidade = l.sk_localidade
GROUP BY l.grupo_territorio
ORDER BY total_vendas DESC;

-- KPI 10: Sazonalidade Mensal (Tendência de Vendas)
-- Explicação: Evolução das vendas ao longo dos meses para identificar picos sazonais.
SELECT 
    t.ano,
    t.mes,
    t.nome_mes,
    SUM(f.valor_total) AS total_vendas
FROM public.f_vendas f
JOIN public.d_tempo t ON f.sk_tempo = t.sk_tempo
GROUP BY t.ano, t.mes, t.nome_mes
ORDER BY t.ano, t.mes;