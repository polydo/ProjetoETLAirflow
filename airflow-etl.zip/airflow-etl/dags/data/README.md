# AdventureWorksCSV
AdventureWorks 2019 CSV Files

Original source of extraction: https://learn.microsoft.com/en-us/sql/samples/adventureworks-install-configure?view=sql-server-ver16&tabs=ssms

Access AdventureWorks 2019 Parquet files at https://github.com/olafusimichael/AdventureWorksParquet

Access a (still) relevant AdventureWorks DB schema at https://blog.jpries.com/wp-content/uploads/2015/12/AdventureWorks2008_db_diagram.pdf
