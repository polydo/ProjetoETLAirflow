import logging
import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime

# Configuração de logs
logger = logging.getLogger(__name__)

DATA_PATH = '/opt/airflow/dags/data'

def get_db_engine():
    hook = PostgresHook(postgres_conn_id='postgres_dw')
    return hook.get_sqlalchemy_engine()

def carregar_dados_brutos():
    """Etapa 1: Extração"""
    logger.info("Lendo arquivo Sales SalesTerritory.csv...")
    df_territory = pd.read_csv(f'{DATA_PATH}/Sales SalesTerritory.csv', sep=',')
    return df_territory

def aplicar_regras_negocio(df_territory):
    """Etapa 2: Transformação"""
    logger.info("Transformando dados geográficos...")

    df_final = df_territory[[
        'TerritoryID', 
        'CountryRegionCode', 
        'Name', 
        'Group'
    ]].copy()

    df_final.columns = [
        'id_territorio_original', 
        'pais', 
        'regiao', 
        'grupo_territorio'
    ]
    
    logger.info(f"Transformação concluída. {len(df_final)} territórios processados.")
    return df_final

def persistir_dados(df):
    """Etapa 3: Carga"""
    logger.info("Iniciando carga na tabela d_localidade...")
    engine = get_db_engine()
    
    with engine.connect() as conn:
        conn.execute("TRUNCATE TABLE public.d_localidade RESTART IDENTITY CASCADE;")
        
        df.to_sql(
            'd_localidade', 
            con=conn, 
            if_exists='append', 
            index=False,
            method='multi'
        )
    logger.info("Carga finalizada com sucesso.")

def fluxo_etl_localidade():
    try:
        df_raw = carregar_dados_brutos()
        df_clean = aplicar_regras_negocio(df_raw)
        persistir_dados(df_clean)
    except Exception as e:
        logger.error(f"Erro no ETL de Localidade: {e}")
        raise

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 0
}

with DAG(
    '02_etl_dim_localidade',
    default_args=default_args,
    schedule=None,
    catchup=False,
    tags=['adventureworks', 'dimensao']
) as dag:

    t_processar_localidade = PythonOperator(
        task_id='processar_dimensao_localidade',
        python_callable=fluxo_etl_localidade
    )