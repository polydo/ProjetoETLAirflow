import logging
import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime

# Configuração de logs para aparecer no Airflow
logger = logging.getLogger(__name__)

DATA_PATH = '/opt/airflow/dags/data'

def get_db_engine():
    """Conexão com o Banco"""
    hook = PostgresHook(postgres_conn_id='postgres_dw')
    return hook.get_sqlalchemy_engine()

def carregar_dados_brutos():
    """Etapa 1: Extração."""
    logger.info("Iniciando leitura dos arquivos CSV...")
    
    # Lendo Customer (Tabela base de ligação)
    df_cust = pd.read_csv(f'{DATA_PATH}/Sales Customer.csv', sep=',')
    
    # Lendo Person (Pessoas Físicas)
    df_person = pd.read_csv(f'{DATA_PATH}/Person Person.csv', sep=',')
    
    # Lendo Store (Lojas)
    df_store = pd.read_csv(f'{DATA_PATH}/Sales Store.csv', sep=',')
    
    return df_cust, df_person, df_store

def aplicar_regras_negocio(df_cust, df_person, df_store):
    """Etapa 2: Transformação e Limpeza."""
    logger.info("Aplicando regras de negócio e joins...")

    # Join 1: Clientes Pessoas Físicas
    df_merge = pd.merge(df_cust, df_person, left_on='PersonID', right_on='BusinessEntityID', how='left')
    
    # Join 2: Clientes Lojas (Para pegar o nome da loja)
    df_merge = pd.merge(df_merge, df_store, left_on='StoreID', right_on='BusinessEntityID', how='left', suffixes=('', '_store'))

    # Lógica de Nome: Se tem nome de pessoa, usa. Se não, usa nome da Loja.
    # Tratamento de nulos para concatenação
    df_merge['FirstName'] = df_merge['FirstName'].fillna('')
    df_merge['LastName'] = df_merge['LastName'].fillna('')
    
    # Cria coluna temporária de nome pessoa
    df_merge['nome_completo_pessoa'] = (df_merge['FirstName'] + ' ' + df_merge['LastName']).str.strip()
    
    # Regra de Coalescência (Prioridade: Pessoa > Loja > Desconhecido)
    df_merge['nome_final'] = df_merge['nome_completo_pessoa']
    
    # Onde o nome da pessoa for vazio, preenche com o nome da loja (Coluna Name vinda do Store.csv)
    mask_loja = df_merge['nome_final'] == ''
    df_merge.loc[mask_loja, 'nome_final'] = df_merge.loc[mask_loja, 'Name'] # 'Name' vem do Store.csv
    
    # Definir Tipo de Cliente
    # Se PersonID existe é Individual, caso contrário é Store
    df_merge['tipo_cliente'] = df_merge['PersonID'].apply(lambda x: 'Individual' if pd.notnull(x) else 'Loja/Revenda')

    # Seleção e Renomeação final para o padrão d_cliente
    df_output = df_merge[['CustomerID', 'nome_final', 'tipo_cliente']].copy()
    df_output.columns = ['id_cliente_original', 'nome_completo', 'tipo_cliente']
    
    # Remove duplicatas
    df_output.drop_duplicates(subset=['id_cliente_original'], inplace=True)
    
    return df_output

def persistir_dados(df):
    """Etapa 3: Carga no Banco de Dados."""
    logger.info(f"Iniciando carga de {len(df)} registros no banco...")
    
    engine = get_db_engine()
    
    with engine.connect() as conn:
        # Limpa a tabela antes de carregar (Full Load)
        conn.execute("TRUNCATE TABLE public.d_cliente RESTART IDENTITY CASCADE;")
        
        # Usa chunksize para não sobrecarregar a memória se o arquivo for grande
        df.to_sql(
            'd_cliente', 
            con=conn, 
            if_exists='append', 
            index=False,
            method='multi',
            chunksize=1000 
        )
    
    logger.info("Carga finalizada com sucesso.")

def fluxo_principal_etl():
    """Função Wrapper que orquestra as chamadas."""
    try:
        # 1. Extract
        raw_cust, raw_person, raw_store = carregar_dados_brutos()
        
        # 2. Transform
        df_tratado = aplicar_regras_negocio(raw_cust, raw_person, raw_store)
        
        # 3. Load
        persistir_dados(df_tratado)
        
    except Exception as e:
        logger.error(f"Falha no processo de ETL: {e}")
        raise # Relança o erro para o Airflow marcar a task como Failed

# Definição da DAG
default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 0
}

with DAG(
    '01_etl_dim_cliente',
    default_args=default_args,
    schedule=None,
    catchup=False,
    tags=['adventureworks', 'dimensao']
) as dag:

    t_processar_cliente = PythonOperator(
        task_id='processar_dimensao_cliente',
        python_callable=fluxo_principal_etl
    )