import logging
import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime

# Configuração de logs
logger = logging.getLogger(__name__)

def get_db_engine():
    hook = PostgresHook(postgres_conn_id='postgres_dw')
    return hook.get_sqlalchemy_engine()

def gerar_datas_base():
    """Etapa 1: Geração (Extract)"""
    logger.info("Gerando range de datas (2010 a 2030)...")
    
    # Cria uma sequência de dias cobrindo todo o período histórico + futuro
    datas = pd.date_range(start='2010-01-01', end='2030-12-31', freq='D')
    df = pd.DataFrame({'data_completa': datas})
    
    return df

def enriquecer_datas(df):
    """Etapa 2: Transformação e Tradução"""
    logger.info("Calculando atributos temporais (Ano, Mês, Semestre)...")

    # Atributos Numéricos Básicos
    df['ano'] = df['data_completa'].dt.year
    df['mes'] = df['data_completa'].dt.month
    df['dia'] = df['data_completa'].dt.day
    df['trimestre'] = df['data_completa'].dt.quarter
    
    # SK (Surrogate Key) em formato Inteiro (YYYYMMDD) - Muito rápido para indexar
    df['sk_tempo'] = df['data_completa'].dt.strftime('%Y%m%d').astype(int)

    # --- TRADUÇÃO PARA PORTUGUÊS (Mapeamento Manual) ---
    # Garantia de funcionar em qualquer servidor, independente do Locale do Docker
    
    mapa_meses = {
        1: 'Janeiro', 2: 'Fevereiro', 3: 'Março', 4: 'Abril',
        5: 'Maio', 6: 'Junho', 7: 'Julho', 8: 'Agosto',
        9: 'Setembro', 10: 'Outubro', 11: 'Novembro', 12: 'Dezembro'
    }
    
    mapa_dias_semana = {
        0: 'Segunda-feira', 1: 'Terça-feira', 2: 'Quarta-feira',
        3: 'Quinta-feira', 4: 'Sexta-feira', 5: 'Sábado', 6: 'Domingo'
    }

    df['nome_mes'] = df['mes'].map(mapa_meses)
    
    # dayofweek do Pandas: 0=Segunda, 6=Domingo
    df['dia_semana'] = df['data_completa'].dt.dayofweek.map(mapa_dias_semana)
    
    # Flag Fim de Semana (Sábado=5 ou Domingo=6)
    df['flag_fim_de_semana'] = df['data_completa'].dt.dayofweek.apply(lambda x: 'S' if x >= 5 else 'N')

    # Seleção final para o banco
    # Colunas esperadas: sk_tempo, data_completa, ano, mes, nome_mes, trimestre, dia_semana, flag_fim_de_semana
    df_final = df[['sk_tempo', 'data_completa', 'ano', 'mes', 'nome_mes', 'trimestre', 'dia_semana', 'flag_fim_de_semana']]
    
    logger.info(f"Datas enriquecidas com sucesso. Total de dias: {len(df_final)}")
    return df_final

def persistir_dados(df):
    """Etapa 3: Carga"""
    logger.info(f"Iniciando carga de {len(df)} registros no banco...")
    engine = get_db_engine()
    
    with engine.connect() as conn:
        conn.execute("TRUNCATE TABLE public.d_tempo RESTART IDENTITY CASCADE;")
        
        # Chunksize ajuda a inserir os ~7000 dias de forma eficiente
        df.to_sql(
            'd_tempo', 
            con=conn, 
            if_exists='append', 
            index=False,
            method='multi', 
            chunksize=1000
        )
    logger.info("Carga d_tempo finalizada.")

def fluxo_etl_tempo():
    """Orquestrador"""
    try:
        # 1. Generate
        df_raw = gerar_datas_base()
        
        # 2. Transform
        df_final = enriquecer_datas(df_raw)
        
        # 3. Load
        persistir_dados(df_final)
        
    except Exception as e:
        logger.error(f"Erro no ETL de Tempo: {e}")
        raise

# Definição da DAG
default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 0
}

with DAG(
    '04_etl_dim_tempo',
    default_args=default_args,
    schedule=None,
    catchup=False,
    tags=['adventureworks', 'dimensao']
) as dag:

    t_processar_tempo = PythonOperator(
        task_id='processar_dimensao_tempo',
        python_callable=fluxo_etl_tempo
    )