import logging
import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime

# Configuração de logs
logger = logging.getLogger(__name__)

DATA_PATH = '/opt/airflow/dags/data'

def get_db_engine():
    hook = PostgresHook(postgres_conn_id='postgres_dw')
    return hook.get_sqlalchemy_engine()

def carregar_dados_brutos():
    """Etapa 1: Extração das 3 tabelas de produto"""
    logger.info("Lendo arquivos de Produto, Subcategoria e Categoria...")
    
    # Leitura dos CSVs
    df_prod = pd.read_csv(f'{DATA_PATH}/Production Product.csv', sep=',')
    df_sub = pd.read_csv(f'{DATA_PATH}/Production ProductSubcategory.csv', sep=',')
    df_cat = pd.read_csv(f'{DATA_PATH}/Production ProductCategory.csv', sep=',')
    
    return df_prod, df_sub, df_cat

def aplicar_regras_negocio(df_prod, df_sub, df_cat):
    """Etapa 2: Transformação e Joins (Denormalização)"""
    logger.info("Cruzando tabelas para montar a dimensão produto...")

    # 1. Join Produto -> Subcategoria
    # Uso de 'left' porque alguns produtos podem não ter subcategoria
    df_merged = pd.merge(
        df_prod, 
        df_sub, 
        on='ProductSubcategoryID', 
        how='left', 
        suffixes=('', '_sub') # Conflito de nome 'Name' vira 'Name' e 'Name_sub'
    )
    
    # 2. Join Resultado -> Categoria
    # A Subcategoria liga com a Categoria pelo ProductCategoryID
    df_merged = pd.merge(
        df_merged, 
        df_cat, 
        on='ProductCategoryID', 
        how='left', 
        suffixes=('', '_cat') # 'Name' vira 'Name_cat'
    )

    # Tratamento de Nulos (Campos de texto)
    colunas_texto = ['Color', 'Name_sub', 'Name_cat', 'ProductModelID']
    for col in colunas_texto:
        if col in df_merged.columns:
            df_merged[col] = df_merged[col].fillna('N/A')

    # Seleção e Renomeação para o padrão do Banco (d_produto)
    # Mapeando: Origem -> Destino
    df_final = df_merged[[
        'ProductID',        # -> id_produto_original
        'Name',             # -> nome_produto
        'ProductModelID',   # -> modelo_produto
        'Color',            # -> cor
        'Name_cat',         # -> nome_categoria
        'Name_sub'          # -> nome_subcategoria
    ]].copy()

    df_final.columns = [
        'id_produto_original', 
        'nome_produto', 
        'modelo_produto', 
        'cor', 
        'nome_categoria', 
        'nome_subcategoria'
    ]
    
    # Converter modelo para string para evitar erro se vier numérico misturado
    df_final['modelo_produto'] = df_final['modelo_produto'].astype(str)

    logger.info(f"Transformação concluída. {len(df_final)} produtos processados.")
    return df_final

def persistir_dados(df):
    """Etapa 3: Carga"""
    logger.info("Iniciando carga na tabela d_produto...")
    engine = get_db_engine()
    
    with engine.connect() as conn:
        conn.execute("TRUNCATE TABLE public.d_produto RESTART IDENTITY CASCADE;")
        
        df.to_sql(
            'd_produto', 
            con=conn, 
            if_exists='append', 
            index=False,
            method='multi',
            chunksize=1000
        )
    logger.info("Carga finalizada com sucesso.")

def fluxo_etl_produto():
    """Orquestrador"""
    try:
        # 1. Extract
        raw_prod, raw_sub, raw_cat = carregar_dados_brutos()
        
        # 2. Transform
        df_clean = aplicar_regras_negocio(raw_prod, raw_sub, raw_cat)
        
        # 3. Load
        persistir_dados(df_clean)
        
    except FileNotFoundError as e:
        logger.error(f"Arquivo não encontrado. Verifique se os 3 CSVs estão na pasta data: {e}")
        raise
    except Exception as e:
        logger.error(f"Falha no processo de ETL: {e}")
        raise

# Definição da DAG
default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 0
}

with DAG(
    '03_etl_dim_produto',
    default_args=default_args,
    schedule=None,
    catchup=False,
    tags=['adventureworks', 'dimensao']
) as dag:

    t_processar_produto = PythonOperator(
        task_id='processar_dimensao_produto',
        python_callable=fluxo_etl_produto
    )