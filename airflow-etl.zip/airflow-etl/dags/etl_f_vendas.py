import logging
import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime

logger = logging.getLogger(__name__)

DATA_PATH = '/opt/airflow/dags/data'

def get_db_engine():
    hook = PostgresHook(postgres_conn_id='postgres_dw')
    return hook.get_sqlalchemy_engine()

def carregar_dados():
    """Etapa 1: Extração"""
    logger.info("Lendo arquivos de Vendas e Produto...")
    
    df_header = pd.read_csv(f'{DATA_PATH}/Sales SalesOrderHeader.csv', sep=',')
    df_detail = pd.read_csv(f'{DATA_PATH}/Sales SalesOrderDetail.csv', sep=',')
    
    df_custo_prod = pd.read_csv(f'{DATA_PATH}/Production Product.csv', sep=',')
    df_custo_prod = df_custo_prod[['ProductID', 'StandardCost']]

    engine = get_db_engine()
    
    logger.info("Carregando dimensões para Lookup...")
    df_dim_prod = pd.read_sql("SELECT sk_produto, id_produto_original FROM d_produto", engine)
    df_dim_cli = pd.read_sql("SELECT sk_cliente, id_cliente_original FROM d_cliente", engine)
    
    # Precisamos do id_territorio_original para bater com o TerritoryID da venda
    df_dim_loc = pd.read_sql("SELECT sk_localidade, id_territorio_original FROM d_localidade", engine)

    return df_header, df_detail, df_custo_prod, df_dim_prod, df_dim_cli, df_dim_loc

def aplicar_regras_negocio(df_header, df_detail, df_custo_prod, df_dim_prod, df_dim_cli, df_dim_loc):
    """Etapa 2: Transformação"""
    logger.info("Iniciando cruzamentos...")

    # 1. Header + Detail
    df_vendas = pd.merge(df_detail, df_header, on='SalesOrderID', how='inner')

    # 2. Trazer Custo
    df_vendas = pd.merge(df_vendas, df_custo_prod, on='ProductID', how='left')
    df_vendas['StandardCost'] = df_vendas['StandardCost'].fillna(0)
    
    # A. Produto
    df_vendas = pd.merge(df_vendas, df_dim_prod, left_on='ProductID', right_on='id_produto_original', how='inner')
    
    # B. Cliente
    df_vendas = pd.merge(df_vendas, df_dim_cli, left_on='CustomerID', right_on='id_cliente_original', how='inner')
    
    # C. Localidade
    # No SalesOrderHeader a coluna é 'TerritoryID'
    df_vendas = pd.merge(df_vendas, df_dim_loc, left_on='TerritoryID', right_on='id_territorio_original', how='inner')
    
    # D. Tempo
    df_vendas['OrderDate'] = pd.to_datetime(df_vendas['OrderDate'])
    df_vendas['sk_tempo'] = df_vendas['OrderDate'].dt.strftime('%Y%m%d').astype(int)

    df_final = pd.DataFrame()
    
    df_final['sk_produto'] = df_vendas['sk_produto']
    df_final['sk_cliente'] = df_vendas['sk_cliente']
    df_final['sk_localidade'] = df_vendas['sk_localidade']
    df_final['sk_tempo'] = df_vendas['sk_tempo']
    
    df_final['numero_pedido'] = df_vendas['SalesOrderNumber']
    df_final['eh_venda_online'] = df_vendas['OnlineOrderFlag'].astype(bool)
    
    df_final['qtd_vendida'] = df_vendas['OrderQty']
    df_final['valor_unitario'] = df_vendas['UnitPrice']
    df_final['custo_unitario'] = df_vendas['StandardCost']
    
    valor_bruto = df_vendas['UnitPrice'] * df_vendas['OrderQty']
    df_final['valor_desconto'] = valor_bruto * df_vendas['UnitPriceDiscount']
    df_final['valor_total'] = df_vendas['LineTotal']

    logger.info(f"Transformação concluída. {len(df_final)} vendas processadas.")
    return df_final

def persistir_dados(df):
    """Etapa 3: Carga"""
    logger.info("Iniciando carga na f_vendas...")
    engine = get_db_engine()
    
    with engine.connect() as conn:
        conn.execute("TRUNCATE TABLE public.f_vendas RESTART IDENTITY;")
        
        df.to_sql(
            'f_vendas', 
            con=conn, 
            if_exists='append', 
            index=False,
            method='multi',
            chunksize=1000
        )
    logger.info("Carga f_vendas finalizada com sucesso!")

def fluxo_etl_fato():
    try:

        header, detail, custo, d_prod, d_cli, d_loc = carregar_dados()
        
        df_pronto = aplicar_regras_negocio(header, detail, custo, d_prod, d_cli, d_loc)
        
        persistir_dados(df_pronto)
        
    except Exception as e:
        logger.error(f"Erro fatal na Fato Vendas: {e}")
        raise

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 0
}

with DAG(
    '05_etl_fato_vendas',
    default_args=default_args,
    schedule=None,
    catchup=False,
    tags=['adventureworks', 'fato']
) as dag:

    t_processar_fato = PythonOperator(
        task_id='processar_fato_vendas',
        python_callable=fluxo_etl_fato
    )