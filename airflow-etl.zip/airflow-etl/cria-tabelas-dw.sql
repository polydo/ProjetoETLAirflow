-- 1. CRIAÇÃO DAS TABELAS DIMENSÃO

-- Dimensão Tempo
CREATE TABLE public.d_tempo (
    sk_tempo INT PRIMARY KEY,              -- Ex: 20230525
    data_completa DATE NOT NULL,           -- 2023-05-25
    ano INT NOT NULL,
    mes INT NOT NULL,
    nome_mes VARCHAR(20) NOT NULL,         -- Janeiro, Fevereiro...
    trimestre INT NOT NULL,                -- 1, 2, 3, 4
    dia_semana VARCHAR(20) NOT NULL,       -- Segunda, Terça...
    flag_fim_de_semana CHAR(1)             -- 'S' ou 'N'
);

-- Dimensão Produto
-- Consolida Product, ProductCategory e ProductSubcategory
CREATE TABLE public.d_produto (
    sk_produto SERIAL PRIMARY KEY,          -- Chave artificial (Surrogate Key) do DW
    id_produto_original INT NOT NULL,       -- ID original do AdventureWorks (ProductReference)
    nome_produto VARCHAR(255),
    modelo_produto VARCHAR(255),
    cor VARCHAR(50),
    nome_categoria VARCHAR(100),            -- Ex: Bikes
    nome_subcategoria VARCHAR(100)          -- Ex: Mountain Bikes
);

-- Dimensão Cliente
-- Consolida dados de Customer e Person/Store
CREATE TABLE public.d_cliente (
    sk_cliente SERIAL PRIMARY KEY,
    id_cliente_original INT NOT NULL,
    nome_completo VARCHAR(255),
    tipo_cliente VARCHAR(50)                -- 'Individual' ou 'Revenda/Loja'
);

-- Dimensão Localidade (Território)
-- Baseada na SalesTerritory
CREATE TABLE public.d_localidade (
    sk_localidade SERIAL PRIMARY KEY,
    id_territorio_original INT NOT NULL,
    pais VARCHAR(100),                      -- Ex: United States
    regiao VARCHAR(100),                    -- Ex: Southwest
    grupo_territorio VARCHAR(100)           -- Ex: North America
);

-- 2. CRIAÇÃO DA TABELA FATO

CREATE TABLE public.f_vendas (
    -- Chaves Estrangeiras ligando às Dimensões
    sk_vendas SERIAL PRIMARY KEY, -- Identificador único da linha no DW
    sk_produto INT NOT NULL REFERENCES public.d_produto(sk_produto),
    sk_cliente INT NOT NULL REFERENCES public.d_cliente(sk_cliente),
    sk_localidade INT NOT NULL REFERENCES public.d_localidade(sk_localidade),
    sk_tempo INT NOT NULL REFERENCES public.d_tempo(sk_tempo),
    numero_pedido VARCHAR(50),              -- SalesOrderNumber (Importante para contar Ticket Médio)
    eh_venda_online BOOLEAN,                -- Flag para diferenciar canais de venda
    qtd_vendida INT,                        -- OrderQty
    valor_unitario NUMERIC(18,4),           -- UnitPrice
    custo_unitario NUMERIC(18,4),           -- StandardCost (Fundamental para calcular LUCRO)
    valor_desconto NUMERIC(18,4),           -- (UnitPriceDiscount * UnitPrice * Qty)
    valor_total NUMERIC(18,4),              -- LineTotal (Valor Líquido da linha)
);

-- 3. ÍNDICES DE PERFORMANCE

-- Índices nas chaves estrangeiras da Fato melhoram muito a performance dos Joins nos KPIs
CREATE INDEX idx_fato_produto ON public.f_vendas(sk_produto);
CREATE INDEX idx_fato_cliente ON public.f_vendas(sk_cliente);
CREATE INDEX idx_fato_tempo ON public.f_vendas(sk_tempo);
CREATE INDEX idx_fato_localidade ON public.f_vendas(sk_localidade);